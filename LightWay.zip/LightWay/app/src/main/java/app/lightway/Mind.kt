package app.lightway
import org.json.*

/** Portable Mind: persona + memory notes + chat + model pointer in one shareable .mind file. */
data class Mind(var name: String = "Light", var persona: String = "You are LightWay, a calm, honest offline assistant. Say when you are unsure.",
    val notes: MutableList<String> = mutableListOf(), var modelRepo: String = "", var modelFile: String = "",
    val chat: MutableList<Pair<String, String>> = mutableListOf()) {
    fun toJson() = JSONObject().put("v", 1).put("name", name).put("persona", persona).put("modelRepo", modelRepo).put("modelFile", modelFile)
        .put("notes", JSONArray(notes)).put("chat", JSONArray(chat.map { JSONArray(listOf(it.first, it.second)) })).toString(2)
    fun systemPrompt() = persona + if (notes.isEmpty()) "" else "\nKnown facts:\n" + notes.joinToString("\n") { "- $it" }
    companion object {
        fun fromJson(s: String): Mind { val j = JSONObject(s); val m = Mind(j.optString("name", "Light"), j.optString("persona"))
            m.modelRepo = j.optString("modelRepo"); m.modelFile = j.optString("modelFile")
            j.optJSONArray("notes")?.let { for (i in 0 until it.length()) m.notes.add(it.getString(i)) }
            j.optJSONArray("chat")?.let { for (i in 0 until it.length()) m.chat.add(it.getJSONArray(i).let { a -> a.getString(0) to a.getString(1) }) }
            return m }
    }
}

package app.lightway
import okhttp3.*
import org.json.JSONObject
import java.io.*

/** Hugging Face: paste "user/repo", list .gguf files, resumable download. */
object Hf {
    private val http = OkHttpClient()
    fun ggufFiles(repo: String): List<String> = http.newCall(Request.Builder().url("https://huggingface.co/api/models/${repo.trim()}").build()).execute().use { r ->
        val s = JSONObject(r.body!!.string()).getJSONArray("siblings")
        (0 until s.length()).map { s.getJSONObject(it).getString("rfilename") }.filter { it.endsWith(".gguf") } }
    fun download(repo: String, file: String, dest: File, onProgress: (Long, Long) -> Unit) {
        val have = if (dest.exists()) dest.length() else 0L
        val req = Request.Builder().url("https://huggingface.co/${repo.trim()}/resolve/main/$file").header("Range", "bytes=$have-").build()
        http.newCall(req).execute().use { r ->
            val resumed = r.code == 206; val start = if (resumed) have else 0L
            val body = r.body!!; val total = start + body.contentLength(); var done = start
            FileOutputStream(dest, resumed).use { o -> val buf = ByteArray(1 shl 16); val i = body.byteStream()
                while (true) { val n = i.read(buf); if (n < 0) break; o.write(buf, 0, n); done += n; onProgress(done, total) } } }
    }
}

package app.lightway
import android.content.ContentResolver
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.flow.*
import org.nehuatl.llamacpp.LlamaHelper   // if red: let Android Studio auto-import LlamaHelper

interface LlmEngine { suspend fun load(uri: String); fun generate(system: String, history: List<Pair<String, String>>, user: String): Flow<String> }

/** Real on-device inference via Kotlin-LlamaCpp (MIT, llama.cpp). */
class LlamaEngine(cr: ContentResolver, scope: CoroutineScope) : LlmEngine {
    private val events = MutableSharedFlow<LlamaHelper.LLMEvent>(extraBufferCapacity = 64, onBufferOverflow = BufferOverflow.DROP_OLDEST)
    private val helper = LlamaHelper(cr, scope, events)
    @Volatile private var ready = false

    override suspend fun load(uri: String) = suspendCancellableCoroutine<Unit> { c ->
        helper.load(path = uri, contextLength = 2048) { ready = true; if (c.isActive) c.resumeWith(Result.success(Unit)) } }

    // ChatML template (Qwen, many Dolphin/Hermes builds). Llama/Gemma models need their own template.
    private fun prompt(system: String, h: List<Pair<String, String>>) = buildString {
        append("<|im_start|>system\n$system<|im_end|>\n")
        h.takeLast(12).forEach { (r, t) -> append("<|im_start|>${if (r == "user") "user" else "assistant"}\n$t<|im_end|>\n") }
        append("<|im_start|>assistant\n") }

    override fun generate(system: String, history: List<Pair<String, String>>, user: String): Flow<String> = channelFlow {
        if (!ready) { send("No model loaded. Open the Models tab, download or import a .gguf, wait for 'Ready'."); return@channelFlow }
        val job = launch { events.collect { e -> when (e) {
            is LlamaHelper.LLMEvent.Ongoing -> send(e.word)
            is LlamaHelper.LLMEvent.Done -> close()
            is LlamaHelper.LLMEvent.Error -> { send("\n[engine error]"); close() }
            else -> {} } } }
        events.subscriptionCount.first { it > 0 }
        helper.predict(prompt(system, history))
        awaitClose { job.cancel() }
    }
}

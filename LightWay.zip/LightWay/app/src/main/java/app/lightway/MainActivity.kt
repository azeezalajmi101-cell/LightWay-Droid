package app.lightway
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.*
import java.io.File

val Gold = Color(0xFFC9A227); val GoldDark = Color(0xFF8A6D0B); val Cream = Color(0xFFFFF8E1)
class MainActivity : ComponentActivity() {
    override fun onCreate(b: Bundle?) { super.onCreate(b); setContent {
        MaterialTheme(colorScheme = lightColorScheme(primary = Gold, onPrimary = Color.White, background = Color.White, surface = Color.White, secondaryContainer = Cream, onSecondaryContainer = GoldDark)) { App() } } }
}

@Composable fun App() {
    val ctx = androidx.compose.ui.platform.LocalContext.current; val scope = rememberCoroutineScope()
    var tab by remember { mutableIntStateOf(0) }; val mind = remember { mutableStateOf(Mind()) }; val engine = remember { LlamaEngine(ctx.contentResolver, CoroutineScope(Dispatchers.IO + SupervisorJob())) }
    val modelsDir = remember { File(ctx.filesDir, "models").apply { mkdirs() } }
    val library = remember { ctx.assets.open("library.txt").bufferedReader().readLines().filter { it.isNotBlank() } }
    LaunchedEffect(Unit) { withContext(Dispatchers.IO) { modelsDir.listFiles()?.firstOrNull { it.name.endsWith(".gguf") }?.let { try { engine.load(Uri.fromFile(it).toString()) } catch (_: Exception) {} } } }
    Scaffold(containerColor = Color.White, bottomBar = { NavigationBar(containerColor = Color.White) {
        listOf("Chat" to Icons.Default.Chat, "Library" to Icons.Default.MenuBook, "Models" to Icons.Default.Memory, "Mind" to Icons.Default.Psychology).forEachIndexed { i, (n, ic) ->
            NavigationBarItem(tab == i, { tab = i }, { Icon(ic, n) }, label = { Text(n) }) } } }) { pad ->
        Box(Modifier.padding(pad).fillMaxSize().padding(12.dp)) { when (tab) {
            0 -> Chat(mind.value, engine, scope)
            1 -> LibraryTab(library)
            2 -> Models(mind.value, engine, modelsDir, scope)
            else -> MindTab(mind)
        } } }
}

@Composable fun Chat(m: Mind, engine: LlmEngine, scope: CoroutineScope) {
    val msgs = remember { mutableStateListOf<Pair<String, String>>().apply { addAll(m.chat) } }; var input by remember { mutableStateOf("") }
    Column { LazyColumn(Modifier.weight(1f)) { items(msgs.size) { i -> val (r, t) = msgs[i]
        Card(Modifier.padding(vertical = 4.dp).fillMaxWidth(), colors = CardDefaults.cardColors(if (r == "user") Cream else Color.White), border = androidx.compose.foundation.BorderStroke(1.dp, Gold)) { Text(t, Modifier.padding(10.dp)) } } }
        Row { OutlinedTextField(input, { input = it }, Modifier.weight(1f), placeholder = { Text("Ask LightWay…") })
            IconButton({ val q = input.trim(); if (q.isEmpty()) return@IconButton; input = ""; msgs.add("user" to q); m.chat.add("user" to q)
                msgs.add("ai" to ""); val idx = msgs.lastIndex
                scope.launch { var acc = ""; engine.generate(m.systemPrompt(), m.chat.toList(), q).collect { acc += it; msgs[idx] = "ai" to acc }; m.chat.add("ai" to acc) } }) { Icon(Icons.Default.Send, "Send", tint = Gold) } } }
}

@Composable fun LibraryTab(entries: List<String>) {
    var q by remember { mutableStateOf("") }
    Column { OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth(), placeholder = { Text("Search offline library") })
        LazyColumn { items(entries.filter { it.contains(q, true) }) { e -> Card(Modifier.padding(vertical = 4.dp).fillMaxWidth(), colors = CardDefaults.cardColors(Cream)) { Text(e, Modifier.padding(12.dp)) } } }
        Text("Verify critical info with trusted sources (try Kiwix).", color = GoldDark) }
}

@Composable fun Models(m: Mind, engine: LlmEngine, dir: File, scope: CoroutineScope) {
    val ctxM = androidx.compose.ui.platform.LocalContext.current
    var repo by remember { mutableStateOf(m.modelRepo) }; var files by remember { mutableStateOf(listOf<String>()) }; var status by remember { mutableStateOf("") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u: Uri? -> u?.let { ctxM.contentResolver.takePersistableUriPermission(it, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION); scope.launch(Dispatchers.IO) { status = "Loading…"; try { engine.load(it.toString()); status = "Ready (local file)" } catch (e: Exception) { status = "Error: ${e.message}" } } } }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(repo, { repo = it }, Modifier.fillMaxWidth(), label = { Text("Hugging Face repo (user/name-GGUF)") })
        Button({ scope.launch(Dispatchers.IO) { status = try { files = Hf.ggufFiles(repo); "${files.size} GGUF files" } catch (e: Exception) { "Error: ${e.message}" } } }, colors = ButtonDefaults.buttonColors(Gold)) { Text("Find GGUF files") }
        OutlinedButton({ picker.launch(arrayOf("*/*")) }) { Text("Import local .gguf") }
        Text(status, color = GoldDark)
        LazyColumn { items(files) { f -> ListItem(headlineContent = { Text(f) }, trailingContent = { TextButton({
            scope.launch(Dispatchers.IO) { try { Hf.download(repo, f, File(dir, f.substringAfterLast('/'))) { d, t -> status = "Downloading ${d * 100 / maxOf(t, 1)}%" }
                m.modelRepo = repo; m.modelFile = f; status = "Loading model…"; engine.load(Uri.fromFile(File(dir, f.substringAfterLast('/'))).toString()); status = "Ready: $f" } catch (e: Exception) { status = "Error: ${e.message}" } } }) { Text("Get", color = Gold) } }) } }
    }
}

@Composable fun MindTab(mind: MutableState<Mind>) {
    val ctx = androidx.compose.ui.platform.LocalContext.current; var note by remember { mutableStateOf("") }; var persona by remember { mutableStateOf(mind.value.persona) }
    val save = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { u -> u?.let { ctx.contentResolver.openOutputStream(it)?.use { o -> o.write(mind.value.toJson().toByteArray()) } } }
    val load = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> u?.let { ctx.contentResolver.openInputStream(it)?.use { i -> mind.value = Mind.fromJson(i.readBytes().decodeToString()); persona = mind.value.persona } } }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Portable Mind", style = MaterialTheme.typography.titleLarge, color = GoldDark)
        OutlinedTextField(persona, { persona = it; mind.value.persona = it }, Modifier.fillMaxWidth(), label = { Text("Persona / system prompt") })
        Row { OutlinedTextField(note, { note = it }, Modifier.weight(1f), label = { Text("Add memory note") }); TextButton({ if (note.isNotBlank()) { mind.value.notes.add(note); note = "" } }) { Text("Add", color = Gold) } }
        Text("${mind.value.notes.size} notes · ${mind.value.chat.size} messages")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button({ save.launch("${mind.value.name}.mind.json") }, colors = ButtonDefaults.buttonColors(Gold)) { Text("Export mind") }
            OutlinedButton({ load.launch(arrayOf("application/json", "*/*")) }) { Text("Import mind") } } }
}

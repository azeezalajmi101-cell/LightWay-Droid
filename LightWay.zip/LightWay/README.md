# LightWay
Offline-first, open-source Android AI: white and gold UI, Hugging Face GGUF model manager, offline survival library, and a **Portable Mind** (persona + memory + chat exported as one `.mind.json`).

## Build
Push to GitHub: Actions builds the APK (artifact `LightWay-debug-apk`). Or open in Android Studio.

## Status
- Done: UI, HF repo browser + resumable download, library, Portable Mind export/import.
- Inference: Kotlin-LlamaCpp (`io.github.ljcamargo:llamacpp-kotlin`, MIT). Uses a ChatML prompt template, so use Qwen/ChatML-style GGUFs first.
- Versions (Kotlin 2.3.20, AGP 8.9.2, Gradle 8.11.1) are my best match and untested: adjust if the build complains.

## Credits and ideas swept from GitHub (check each license before copying code)
- SmolChat-Android (Apache-2.0): `smollm` JNI module for llama.cpp, the engine to reuse
- PocketPal AI (MIT): model manager UX, performance metrics, TTS idea
- OfflineLLM (Apache-2.0): no-INTERNET-permission build flavor, biometric lock, secure delete
- Kotlin-LlamaCpp by ljcamargo (MIT): the inference library used
- llama.cpp (MIT), Kiwix (offline Wikipedia/manuals), whisper.cpp (voice input)
Logo is original (gold light-path over a sun), not LMArena's.
